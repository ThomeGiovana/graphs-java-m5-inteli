public class RightTriangle {
    public static void main(
            String[] args
    ) {

        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        int c = Integer.parseInt(args[2]);

        int max = Math.max(a, Math.max(b, c));
        int min = Math.min(a, Math.min(b, c));
        int dif = a + b + c - max - min;

        System.out.println(
                a > 0 && b > 0 && c > 0 && Math.pow(min, 2) + Math.pow(dif, 2) == Math.pow(max, 2));

    }
}
