public class Clock {
    private int hour, minute;

    // Creates a clock whose initial time is h hours and m minutes.
    public Clock(int h, int m) {
        if (h < 0 || h > 23 || m < 0 || m > 59) throw new IllegalArgumentException();
        this.hour = h;
        this.minute = m;
    }

    // Creates a clock whose initial time is specified as a string, using the format HH:MM.
    public Clock(String s) {
        if (!s.contains(":")) throw new IllegalArgumentException();
        int middle = s.indexOf(':');
        String stringHour = s.substring(0, middle);
        String stringMinute = s.substring(middle + 1);
        if (stringHour.length() != 2 || stringMinute.length() != 2)
            throw new IllegalArgumentException();
        this.hour = Integer.parseInt(stringHour);
        this.minute = Integer.parseInt(stringMinute);
    }

    // Returns a string representation of this clock, using the format HH:MM.
    public String toString() {
        String stringHour = Integer.toString(this.hour);
        String stringMinute = Integer.toString(this.minute);
        if (stringHour.length() == 1) stringHour = "0" + stringHour;
        if (stringMinute.length() == 1) stringMinute = "0" + stringMinute;
        return stringHour + ":" + stringMinute;
    }

    // Is the time on this clock earlier than the time on that one?
    public boolean isEarlierThan(Clock that) {
        return (this.hour < that.hour || (this.hour == that.hour && this.minute < that.minute));
    }

    // Adds 1 minute to the time on this clock.
    public void tic() {
        if (this.minute == 59) {
            this.minute = 0;
            this.hour += 1;
            if (this.hour > 23) this.hour = 0;
        }
        else {
            this.minute++;
        }
    }

    // Adds Δ minutes to the time on this clock.
    public void toc(int delta) {
        if (delta < 0) throw new IllegalArgumentException();
        int totalMinutes = delta + this.minute + this.hour;
        this.hour = (totalMinutes / 60) % 24;
        this.minute = totalMinutes % 60;
    }

    // Test client (see below).
    public static void main(String[] args) {
        Clock time1 = new Clock(23, 55);
        Clock time2 = new Clock("18:15");
        System.out.println(time1.toString());
        time1.tic();
        System.out.println(time1.toString());
        time1.toc(15);
        System.out.println(time1.toString());
        System.out.println(time1.isEarlierThan(time2));
        System.out.println(time2.toString());
        time2.toc(1442);
        System.out.println(time2.toString());
    }
}
