public class ColorHSB {
    private int hue, saturation, brightness;
    private static final int MAX_SATURATION_BRIGHTNESS = 100;
    private static final int MAX_HUE = 359;
    private static final int ANGLE = 360;

    // Creates a color with hue h, saturation s, and brightness b.
    public ColorHSB(int h, int s, int b) {
        if (s < 0 || s > MAX_SATURATION_BRIGHTNESS) throw new IllegalArgumentException();
        if (b < 0 || b > MAX_SATURATION_BRIGHTNESS) throw new IllegalArgumentException();
        if (h < 0 || h > MAX_HUE) throw new IllegalArgumentException();
        this.hue = h;
        this.brightness = b;
        this.saturation = s;
    }

    // Returns a string representation of this color, using the format (h, s, b).
    public String toString() {
        return "(" + this.hue + ", " + this.saturation + ", " + this.brightness + ")";
    }

    // Is this color a shade of gray?
    public boolean isGrayscale() {
        return (this.saturation == 0 || this.brightness == 0);
    }

    // Returns the squared distance between the two colors.
    public int distanceSquaredTo(ColorHSB that) {
        return Math.min((that.hue - hue) * (that.hue - hue),
                        (ANGLE - Math.abs(that.hue - hue)) * (ANGLE - Math.abs(that.hue - hue)))
                + (that.saturation - saturation) * (that.saturation
                - saturation) + (that.brightness - brightness) * (that.brightness - brightness);
    }

    // Sample client (see below).
    public static void main(String[] args) {
        int h = Integer.parseInt(args[0]);
        int s = Integer.parseInt(args[1]);
        int b = Integer.parseInt(args[2]);
        ColorHSB color = new ColorHSB(h, s, b);
        ColorHSB bestColor = color;
        int minDist = ANGLE * ANGLE * ANGLE;
        String cbest = "";
        while (!StdIn.isEmpty()) {
            String name = StdIn.readString();
            int h2 = StdIn.readInt();
            int s2 = StdIn.readInt();
            int b2 = StdIn.readInt();
            ColorHSB color2 = new ColorHSB(h2, s2, b2);
            if (color.distanceSquaredTo(color2) < minDist) {
                minDist = color.distanceSquaredTo(color2);
                bestColor = color2;
                cbest = name;
            }
        }
        StdOut.println(cbest + " " + bestColor.toString());
    }
}
