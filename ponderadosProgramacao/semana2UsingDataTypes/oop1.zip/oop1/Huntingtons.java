/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */
public class Huntingtons {
    public static int maxRepeats(String dna) {
        String gene = "CAG";
        int maxRepeats = 0;
        int countRepeats = 0;
        int i = 0;
        while (i < (dna.length() - 2)) {
            String firstGene = dna.substring(i, i + 3);
            if (firstGene.equals(gene)) {
                countRepeats++;
                i += 3;
                if (countRepeats > maxRepeats) {
                    maxRepeats = countRepeats;
                }
            }
            else {
                i++;
                countRepeats = 0;
            }
        }
        return maxRepeats;
    }

    public static String removeWhitespace(String s) {
        String dna;
        dna = s.replace(" ", "");
        dna = dna.replace("\t", "");
        dna = dna.replace("\n", "");
        return dna;
    }

    public static String diagnose(int maxRepeats) {
        if (maxRepeats < 10 || maxRepeats > 180) return "not human";
        if (maxRepeats < 36) return "normal";
        if (maxRepeats < 40) return "high risk";
        else return "Huntington’s";
    }

    public static void main(String[] args) {
        String fileName = args[0];
        In file = new In(fileName);
        String dna = file.readAll();
        dna = removeWhitespace(dna);
        int maxRepeats = maxRepeats(dna);
        System.out.print("max repeats = " + maxRepeats + "\n" + diagnose(maxRepeats) + "\n");

    }
}
