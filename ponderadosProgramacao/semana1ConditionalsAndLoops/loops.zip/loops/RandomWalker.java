public class RandomWalker {
    public static void main(String[] args) {
        int x = 0;
        int y = 0;
        int direction;
        int r = Integer.parseInt(args[0]);
        int distance = 0;
        int steps;

        System.out.println("(" + x + ", " + y + ")");
        for (steps = 0; distance < r; steps++) {
            direction = (int) (Math.random() * 4) + 1;
            if (direction == 1) { // north
                y += 1;
                distance += 1;
            }
            else if (direction == 2) { // east
                x += 1;
            }
            else if (direction == 3) { // south
                y -= 1;
            }
            else if (direction == 4) { // west
                x -= 1;
            }
            distance = Math.abs(x) + Math.abs(y);
            System.out.println("(" + x + ", " + y + ")");
        }
        System.out.println("steps = " + steps);
    }
}
