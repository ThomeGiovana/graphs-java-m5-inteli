public class RandomWalkers {
    public static void main(String[] args) {
        int r = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);
        int direction, steps;
        double average;
        int distance = 0;
        int stepSum = 0;
        int x = 0;
        int y = 0;

        for (int i = 0; i < trials; i++) {
            for (steps = 0; distance < r; steps++) {
                direction = (int) (Math.random() * 4) + 1;
                if (direction == 1) { // north
                    y += 1;
                    distance += 1;
                }
                else if (direction == 2) { // east
                    x += 1;
                }
                else if (direction == 3) { // south
                    y -= 1;
                }
                else if (direction == 4) { // west
                    x -= 1;
                }
                distance = Math.abs(x) + Math.abs(y);
            }
            stepSum += steps;
        }
        average = (double) stepSum / (double) trials;
        System.out.println("average number of steps = " + average);
    }
}
